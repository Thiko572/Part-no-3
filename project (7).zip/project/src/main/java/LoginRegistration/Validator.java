package LoginRegistration;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Validator {
    
    
    
  public  boolean isValidUsername(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }
  
    public  boolean isValidPassword(String password) {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return password != null && password.matches(regex);
    }
    
    public  boolean isValidCellphone(String cellphone) {
        String regex = "^\\+[0-9]{1,3}[0-9]{7,12}$"; // +<code><number>
        return cellphone != null && cellphone.matches(regex);
    }


 
    
}
