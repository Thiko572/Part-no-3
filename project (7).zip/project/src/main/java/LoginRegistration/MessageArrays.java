/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LoginRegistration;

import java.util.Arrays;

/**
 *
 * @author delro
 */
public class MessageArrays {
    
     private static Message[] sentMessages = new Message[0];
    private static Message[] disregardedMessages = new Message[0];
    private static Message[] storedMessages = new Message[0];
    
    
    public static Message[] getSentMessages() {
        return sentMessages;
    }

    public static Message[] getDisregardedMessages() {
        return disregardedMessages;
    }

    public static Message[] getStoredMessages() {
        return storedMessages;
    }
    
    
    public static void addSentMessage(Message message) {
        sentMessages = Arrays.copyOf(sentMessages, sentMessages.length + 1);
        sentMessages[sentMessages.length - 1] = message;
    }
    
     public static void addDisregardedMessage(Message message) {
        disregardedMessages = Arrays.copyOf(disregardedMessages, disregardedMessages.length + 1);
        disregardedMessages[disregardedMessages.length - 1] = message;
    }
     
      public static void addStoredMessage(Message message) {
        storedMessages = Arrays.copyOf(storedMessages, storedMessages.length + 1);
        storedMessages[storedMessages.length - 1] = message;
    }
      
    
    public static Message findByMessageId(String id) {
        for (Message msg : sentMessages) {
            if (msg.getMessageId().equals(id)) {
                return msg;
            }
        }
        return null;
    }

    public static Message findByMessageHash(String hash) {
        for (Message msg : sentMessages) {
            if (msg.getMessageHash().equals(hash)) {
                return msg;
            }
        }
        return null;
    }

    public static boolean deleteByHash(String hash) {
        for (int i = 0; i < sentMessages.length; i++) {
            if (sentMessages[i].getMessageHash().equals(hash)) {
                Message[] newArray = new Message[sentMessages.length - 1];
                System.arraycopy(sentMessages, 0, newArray, 0, i);
                System.arraycopy(sentMessages, i + 1, newArray, i, sentMessages.length - i - 1);
                sentMessages = newArray;
                return true;
            }
        }
        return false;
    }

    public static Message findLongestMessage() {
        if (sentMessages.length == 0) return null;

        Message longest = sentMessages[0];
        for (Message msg : sentMessages) {
            if (msg.getContent().length() > longest.getContent().length()) {
                longest = msg;
            }
        }
        return longest;
    }

    public static Message[] findByRecipient(String recipient) {
        Message[] result = new Message[0];
        for (Message msg : sentMessages) {
            if (msg.getRecipientNumber().equalsIgnoreCase(recipient)) {
                result = Arrays.copyOf(result, result.length + 1);
                result[result.length - 1] = msg;
            }
        }
        return result;
    }

    public static void displayFullReport() {
        System.out.println("\n=== 📊 SENT MESSAGES REPORT ===");
        if (sentMessages.length == 0) {
            System.out.println("📭 No messages sent yet.");
            return;
        }

        for (Message msg : sentMessages) {
            System.out.println("--------------------------------");
            System.out.println("🆔 ID: " + msg.getMessageId());
            System.out.println("🔑 Hash: " + msg.getMessageHash());
            System.out.println("👤 Sender: " + msg.getSender());
            System.out.println("📞 Recipient: " + msg.getRecipientNumber());
            System.out.println("✉️ Message: " + msg.getContent());
        }
        System.out.println("--------------------------------");
        System.out.println("📦 Total messages: " + sentMessages.length);
    }
      
    
}
