package LoginRegistration;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {

    private static final String DRAFT_FILE = "draftMessages.json";
    private static ObjectMapper mapper = new ObjectMapper(); // <-- instantiate mapper

    // Save drafts to JSON
    public static void saveDrafts(List<Message> drafts) {
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(new File(DRAFT_FILE), drafts);
        } catch (Exception e) {
            System.out.println("❌ Failed to save drafts: " + e.getMessage());
        }
    }

    // Load drafts from JSON
    public static List<Message> loadDrafts() {
        try {
            File file = new File(DRAFT_FILE);
            if (!file.exists()) return new ArrayList<>();
            return mapper.readValue(file, new TypeReference<List<Message>>() {});
        } catch (Exception e) {
            System.out.println("❌ Failed to load drafts: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
