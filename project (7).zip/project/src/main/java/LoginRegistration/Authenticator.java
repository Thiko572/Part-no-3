package LoginRegistration;

import java.util.HashMap;
import java.util.Map;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Authenticator {
    
     private Map<String, User> users = new HashMap<>();
     private Validator validator = new Validator(); 
    
    
     public String register(String firstName, String lastName, String username, String password, String cellphone) {
        if (!validator.isValidUsername(username)) {
            return "Username is not correctly formatted,\n please ensure username contains an underscore and is no more than 5 characters" ;
        }
        if (!validator.isValidPassword(password)) {
            return "Password is not correctly formatted,\n please ensure that the password is wt least eight characters long,\n contains a capital letter"
                    + "\n,a number and a special character ";
        }
        if (!validator.isValidCellphone(cellphone)) {
            return " Cellphone number incorrectly formatted or does not contain internation code";
        }
        if (users.containsKey(username)) {
            return " Username already exists!";
        }

        User newUser = new User(firstName, lastName, username, password, cellphone);
        users.put(username, newUser);
        return "Username successfuly captured \n password captured successfully"+"\n cellphone number successfully captured";
    }
   
 public String login(String username, String password) {
    if (users.containsKey(username)) {
        User user = users.get(username);
        if (user.getPassword().equals(password)) {
            return "✅ Login successful! Welcome " + user.getFirstName() + " " + user.getLastName() +
                   "\n📱 cellphone: " + user.getCellphoneNumber();
        }
    }
    return "❌ Invalid credentials!";
}
    
    
    
}
