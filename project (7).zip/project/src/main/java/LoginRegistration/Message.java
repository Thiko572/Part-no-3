package LoginRegistration;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class Message {
    private static AtomicInteger totalMessages = new AtomicInteger(0);

    private String messageId;
    private String sender;
    private String recipientNumber;
    private String content;
    private String messageHash; // Auto-generated hash

    // Constructor
    public Message(String sender, String recipientNumber, String content) {
        this.sender = sender;

        // Validate recipient number
        if (!isValidRecipientNumber(recipientNumber)) {
            displayInvalidRecipientMessage();
            throw new IllegalArgumentException("Invalid recipient number format.");
        }

        // Validate message length
        if (!isValidMessageLength(content)) {
            displayMessageTooLong();
            throw new IllegalArgumentException("Message too long.");
        }

        this.recipientNumber = recipientNumber;
        this.content = content.trim();
        this.messageId = generateUniqueId();
        this.messageHash = createMessageHash();
        totalMessages.incrementAndGet();
    }

    // Generate 10-digit unique ID
    private String generateUniqueId() {
        Random random = new Random();
        long number = 1000000000L + (long) (random.nextDouble() * 8999999999L);
        return String.valueOf(number);
    }

    // Generate message hash
    private String createMessageHash() {
        String[] words = content.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;

        // first 2 digits of message ID
        String idPart = messageId.substring(0, 2);

        return idPart + ":" + firstWord + " " + lastWord;
    }

    // Validation: message length <= 250 chars
    public static boolean isValidMessageLength(String content) {
        return content != null && content.length() <= 250;
    }

    // Validation: recipient number must start with "+" and digits
    public static boolean isValidRecipientNumber(String recipientNumber) {
        return recipientNumber != null && recipientNumber.matches("^\\+\\d{7,15}$");
    }

    // Display message when message too long
    public static void displayMessageTooLong() {
        System.out.println("❌ Message too long! The message cannot exceed 250 characters.");
    }

    // Display message when recipient number is invalid
    public static void displayInvalidRecipientMessage() {
        System.out.println("❌ Invalid recipient number! Must include '+' and country code (e.g., +27608697402).");
    }

    // Getters
    public String getMessageId() {
        return messageId;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipientNumber() {
        return recipientNumber;
    }

    public String getContent() {
        return content;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public static int getTotalMessages() {
        return totalMessages.get();
    }
    
    public boolean checkMessageId() {
    return String.valueOf(messageId).length() == 10;
}


    @Override
    public String toString() {
        return "Message ID: " + messageId +
               "\nHash: " + messageHash +
               "\nFrom: " + sender +
               "\nTo: " + recipientNumber +
               "\nContent: " + content;
    }
}
