package com.mycompany.project;

import LoginRegistration.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Project {

    private static final Scanner scanner = new Scanner(System.in);
    private static final Authenticator auth = new Authenticator();
    private static final List<Message> draftMessages = MessageStorage.loadDrafts();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Register\n2. Login\n3. Exit");
            System.out.print("Choose option: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> handleRegister();
                case "2" -> handleLogin();
                case "3" -> { System.out.println("👋 Bye!"); return; }
                default -> System.out.println("❌ Invalid option!");
            }
        }
    }

    private static void handleRegister() {
        System.out.println("\n=== REGISTRATION ===");
        System.out.print("First Name: "); String firstName = scanner.nextLine();
        System.out.print("Last Name: "); String lastName = scanner.nextLine();
        System.out.print("Username (underscore, max 5 chars): "); String username = scanner.nextLine();
        System.out.print("Password: "); String password = scanner.nextLine();
        System.out.print("Cellphone (+countrycode...): "); String cellphone = scanner.nextLine();

        System.out.println(auth.register(firstName, lastName, username, password, cellphone));
    }

    private static void handleLogin() {
        System.out.println("\n=== LOGIN ===");
        System.out.print("Username: "); String username = scanner.nextLine();
        System.out.print("Password: "); String password = scanner.nextLine();
        String result = auth.login(username, password);
        System.out.println(result);
        if (result.contains("✅")) showUserMenu(username);
    }

    private static void showUserMenu(String username) {
        while (true) {
            System.out.println("\n=== 📬 USER MENU ===");
            System.out.println("1. Send Message");
            System.out.println("2. View Sent Messages");
            System.out.println("3. View Draft Messages");
            System.out.println("4. View Disregarded Messages");
            System.out.println("5. View Longest Message");
            System.out.println("6. Search Message by ID");
            System.out.println("7. Search Messages by Recipient");
            System.out.println("8. Delete Message by Hash");
            System.out.println("9. Full Sent Messages Report");
            System.out.println("10. Logout");
            System.out.print("Choose: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> sendMessage(username);
                case "2" -> viewArrayMessages();
                case "3" -> viewDraftMessages();
                case "4" -> viewDisregardedMessages();
                case "5" -> viewLongestFromArray();
                case "6" -> searchMessageByIdArray();
                case "7" -> searchMessagesByRecipientArray();
                case "8" -> deleteMessageByHashArray();
                case "9" -> MessageArrays.displayFullReport();
                case "10" -> { System.out.println("👋 Logged out."); return; }
                default -> System.out.println("❌ Invalid choice.");
            }
        }
    }

    private static void sendMessage(String username) {
        System.out.print("Recipient (+code...): ");
        String recipientNumber = scanner.nextLine();
        System.out.print("Message: ");
        String content = scanner.nextLine();
        try {
            Message message = new Message(username, recipientNumber, content);
            System.out.println("1. Send now\n2. Disregard\n3. Store as draft");
            String option = scanner.nextLine();

            switch (option) {
                case "1" -> { MessageArrays.addSentMessage(message); System.out.println("📩 Sent!"); }
                case "2" -> { MessageArrays.addDisregardedMessage(message); System.out.println("🗑️ Disregarded."); }
                case "3" -> { draftMessages.add(message); MessageStorage.saveDrafts(draftMessages); System.out.println("💾 Draft saved."); }
                default -> System.out.println("❌ Invalid option.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void viewDraftMessages() {
        if (draftMessages.isEmpty()) {
            System.out.println("📭 No drafts.");
            return;
        }
        System.out.println("\n=== DRAFT MESSAGES ===");
        for (int i = 0; i < draftMessages.size(); i++) {
            Message m = draftMessages.get(i);
            System.out.println((i + 1) + ". " + m.getRecipientNumber() + " | " + m.getContent());
        }
    }

    private static void viewArrayMessages() {
        Message[] sent = MessageArrays.getSentMessages();
        if (sent.length == 0) {
            System.out.println("📭 No sent messages yet.");
            return;
        }
        System.out.println("\n=== SENT MESSAGES ===");
        for (Message msg : sent)
            System.out.println("🆔 " + msg.getMessageId() + " | 📞 " + msg.getRecipientNumber() + " | " + msg.getContent());
    }

    private static void viewDisregardedMessages() {
        Message[] disregarded = MessageArrays.getDisregardedMessages();
        if (disregarded.length == 0) { System.out.println("🗑️ No disregarded messages."); return; }
        System.out.println("\n=== DISREGARDED MESSAGES ===");
        for (Message msg : disregarded)
            System.out.println("🆔 " + msg.getMessageId() + " | " + msg.getRecipientNumber() + " | " + msg.getContent());
    }

    private static void viewLongestFromArray() {
        Message m = MessageArrays.findLongestMessage();
        if (m == null) { System.out.println("📭 No messages yet."); return; }
        System.out.println("\n=== 📏 LONGEST MESSAGE ===");
        System.out.println("Recipient: " + m.getRecipientNumber());
        System.out.println("Message: " + m.getContent());
        System.out.println("Length: " + m.getContent().length());
    }

    private static void searchMessageByIdArray() {
        System.out.print("Enter Message ID: ");
        String id = scanner.nextLine();
        Message m = MessageArrays.findByMessageId(id);
        if (m == null) System.out.println("❌ Not found.");
        else System.out.println("✅ Found -> " + m.getRecipientNumber() + ": " + m.getContent());
    }

    private static void searchMessagesByRecipientArray() {
        System.out.print("Recipient number: ");
        String num = scanner.nextLine();
        Message[] found = MessageArrays.findByRecipient(num);
        if (found.length == 0) System.out.println("❌ No messages.");
        else for (Message m : found) System.out.println("🆔 " + m.getMessageId() + " | " + m.getContent());
    }

    private static void deleteMessageByHashArray() {
        System.out.print("Enter hash: ");
        String hash = scanner.nextLine();
        boolean ok = MessageArrays.deleteByHash(hash);
        System.out.println(ok ? "🗑️ Deleted." : "❌ Not found.");
    }
}
