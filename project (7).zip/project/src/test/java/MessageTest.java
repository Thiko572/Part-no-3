
import LoginRegistration.Message;
import LoginRegistration.MessageStorage;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author delro
 */
public class MessageTest {
    
        @Test
    @DisplayName("✅ Validate all loaded messages from JSON are correct")
    void testLoadedMessagesFromJson() {
        List<Message> messages = MessageStorage.loadDrafts();
        assertNotNull(messages, "Messages list should not be null");

        if (messages.isEmpty()) {
            System.out.println("⚠️ No draft messages found. Run the app and store a few messages first.");
            return;
        }

        for (Message msg : messages) {
            assertTrue(msg.checkMessageId(), "Message ID should be 10 digits");
            assertNotNull(msg.getMessageHash(), "Message hash should not be null");
            assertTrue(msg.getRecipientNumber().startsWith("+"), "Recipient should start with +");
            assertTrue(msg.getContent().length() <= 250, "Message should not exceed 250 characters");

            System.out.println("✅ Verified message: " + msg.getMessageId() + " to " + msg.getRecipientNumber());
        }
    }

    
}
