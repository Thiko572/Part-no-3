import LoginRegistration.Authenticator;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import static org.junit.jupiter.api.Assertions.*;

class AuthenticatorParameterizedTest {

    @ParameterizedTest
    @CsvSource({
        "'Del','_del','980604@Del','Password1!','+27608697402',true",
        "'Bad','user','bad','short','+2712345678',false"
    })
    void testRegistration(String firstName, String lastName, String username,
                          String password, String cellphone, boolean expectedSuccess) {

        Authenticator auth = new Authenticator();
        String result = auth.register(firstName, lastName, username, password, cellphone);
        boolean success = result.contains("✅ Registration successful");
        assertEquals(expectedSuccess, success);
    }
}
