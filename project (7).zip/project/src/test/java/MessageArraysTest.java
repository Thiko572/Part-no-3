

import LoginRegistration.Message;
import LoginRegistration.MessageArrays;
import org.junit.jupiter.api.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MessageArraysTest {

    private static Message msg1;
    private static Message msg2;
    private static Message msg3;

    @BeforeAll
    public static void setup() {
        // Clear and initialize test data
        msg1 = new Message("Alice", "+27123456789", "Hello Bob, how are you?");
        msg2 = new Message("Alice", "+27123456789", "This is a very long message to test if the longest message detection works perfectly fine and accurately compares message lengths.");
        msg3 = new Message("Bob", "+27876543210", "Quick message for Alice.");

        // Add to arrays
        MessageArrays.addSentMessage(msg1);
        MessageArrays.addSentMessage(msg2);
        MessageArrays.addSentMessage(msg3);
    }

    @Test
    @Order(1)
    @DisplayName("✅ Test: Longest Message Detection")
    public void testLongestMessage() {
        Message longest = MessageArrays.findLongestMessage();
        assertNotNull(longest, "Longest message should not be null");
        assertEquals(msg2.getMessageId(), longest.getMessageId(), "Should return the longest message by content length");
        System.out.println("Longest Message: " + longest.getContent());
    }

    @Test
    @Order(2)
    @DisplayName("✅ Test: Full Report Displays All Sent Messages")
    public void testFullReportOutput() {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        System.setOut(new PrintStream(output));

        MessageArrays.displayFullReport();

        String report = output.toString();
        assertTrue(report.contains("FULL SENT MESSAGES REPORT"), "Report title should appear");
        assertTrue(report.contains(msg1.getMessageId()), "First message ID should appear in the report");
        assertTrue(report.contains(msg3.getRecipientNumber()), "Recipient number should appear in the report");

        System.setOut(System.out); // reset output
    }

    @Test
    @Order(3)
    @DisplayName("✅ Test: Search Messages by Recipient")
    public void testSearchByRecipient() {
        Message[] found = MessageArrays.findByRecipient("+27123456789");
        assertEquals(2, found.length, "There should be two messages sent to +27123456789");
        for (Message m : found) {
            System.out.println("Found message to " + m.getRecipientNumber() + " -> " + m.getContent());
        }
    }

    @Test
    @Order(4)
    @DisplayName("✅ Test: Delete a Message by Hash")
    public void testDeleteByHash() {
        String hashToDelete = msg3.getMessageHash();
        boolean deleted = MessageArrays.deleteByHash(hashToDelete);
        assertTrue(deleted, "Message should be deleted successfully");
        assertNull(MessageArrays.findByMessageId(msg3.getMessageId()), "Deleted message should not be found by ID");
        System.out.println("Deleted message hash: " + hashToDelete);
    }

    @Test
    @Order(5)
    @DisplayName("✅ Test: Retrieve All Messages (Sent + Stored) by Recipient")
    public void testAllMessagesByRecipient() {
        // Add a stored message for same recipient
        Message storedMsg = new Message("Alice", "+27123456789", "Stored for later delivery.");
        MessageArrays.addStoredMessage(storedMsg);

        // Collect all messages sent OR stored for this recipient
        Message[] sent = MessageArrays.findByRecipient("+27123456789");
        Message[] stored = MessageArrays.getStoredMessages();

        long total = List.of(sent).stream()
                .filter(m -> m.getRecipientNumber().equals("+27123456789"))
                .count()
                + List.of(stored).stream()
                .filter(m -> m.getRecipientNumber().equals("+27123456789"))
                .count();

        assertTrue(total >= 3, "There should be at least 3 messages (2 sent + 1 stored)");
        System.out.println("Total messages (sent + stored) for recipient +27123456789: " + total);
    }
}
